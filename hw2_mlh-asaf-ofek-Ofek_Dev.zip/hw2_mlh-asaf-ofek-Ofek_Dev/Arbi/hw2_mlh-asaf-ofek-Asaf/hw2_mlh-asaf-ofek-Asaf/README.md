# Homework2
HW2 of MLH course, Winter 20-21

This assignment relates to the detection of Type 1 Diabetes (T1D), and it includes theoretical and coding parts. Here, you won't receive a jupyter notebook sheet, as we want to prepare you to a real life situations.
Try to be as informative and accurate as you can, illustrate the data and keep following the notes from last assinments in regards (units, labels...). 
In addition, explain your actions and considerations, and comment your code.

You're welcome to use any package you'd like to use.

Behatzlacha!
